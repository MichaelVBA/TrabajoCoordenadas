package maps;
public class Coordenada{
public double lat;
public double lonj;
}
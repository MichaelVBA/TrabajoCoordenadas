package clases;

public class titulado extends
profesor{
public String ZIP;
public String colegio;
}
import java.util.*;
import java.util.Scanner;
import java.lang.Math;
import java.util.InputMismatchException; // No olvides importar la excepción
import maps.Coordenada; //Aqui importo una clase
class Main {
  public static void maps(){
   
  }
  public static void main(String[] args) {
   ArrayList<Coordenada> lista = new ArrayList<Coordenada>();

    double Latitud, Longitud;
    int nDatos;
    Scanner input = new Scanner(System.in);

    System.out.println("INGRESA EL NUMERO DE COORDENADAS QUE VA UTILIZAR :");
    System.out.println("================================================");
    nDatos = input.nextInt();
    
    for (int x = 0; x < nDatos; x++) {
      System.out.println("");
      System.out.println("DATO" + (x + 1));
      System.out.println("");
      System.out.println("Ingrese latitud: " + (x + 1));
      Latitud = input.nextDouble();
      System.out.println("Ingrese longitud: " + (x + 1));
      Longitud = input.nextDouble();

      Coordenada o = new Coordenada();
      o.lat = Latitud;
      o.lonj = Longitud;

      lista.add(x, o);

    }
    System.out.println("******************************************************");

    System.out.println("https://www.keene.edu/campus/maps/tool/?coordinates=");
    for (int x = 0; x <= nDatos; x++) {
      if (x != nDatos) {
        System.out.print(lista.get(x).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(x).lonj);
        System.out.print("%0A");
      } else {
        System.out.print(lista.get(0).lat);
        System.out.print("%2C%20");
        System.out.print(lista.get(0).lonj);
      }
    }
   
    System.out.println("\n YUGIOH!");
  //Declarar entero
  int n = 1;
  double z = 12.12;
  boolean ApareceElMagoOscuro=true;
  if (ApareceElMagoOscuro){
    System.out.println("El personaje es Yugi");
  }
  else{
    System.out.println("Personaje desconocido");
  }
   System.out.println("Ejercicios");
   int x = 40;
   int y = 8;
   int resultado = 0;
   resultado = x+y;
   System.out.println("La Suma es "+ resultado);
    int respuesta = 0;
   respuesta = x*y;
   System.out.println("La Multiplicacion es "+ respuesta);
    double rpt = 0;
   rpt = x/y;
   System.out.println("La Division es "+ rpt);
     double raiz=0;
     raiz = Math.pow(x, y);
     System.out.println("La raiz es "+ raiz);
   for(int i =0; x>i;i++){
     System.out.println("Hola");
   
   }
   maps();
  }
}